package com.beetlware.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beetlware.dto.AppointmentModel;
import com.beetlware.entity.Appointments;

@Repository
public interface AppointmentsRepository extends JpaRepository<Appointments, Long> {

	List<AppointmentModel> findByAppointmentDate(Date appointmentDate);

	List<AppointmentModel> findByPatientName(String patientName);

	List<Appointments> findByPatientId(Long patientId);

}
