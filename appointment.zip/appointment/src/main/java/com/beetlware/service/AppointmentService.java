package com.beetlware.service;

import java.util.Date;
import java.util.List;

import com.beetlware.dto.AppointmentModel;
import com.beetlware.entity.Appointments;

public interface AppointmentService {

	public void addAppointment(Appointments appointment);

	public void cancelAppointment(Long appointmentId, String cancellationReason);

	public List<AppointmentModel> getAppointmentsByDate(Date date);

	public List<AppointmentModel> getAppointmentsByPatient(String patientName);

	public List<Appointments> getPatientAppointmentHistory(Long patientId);
}
