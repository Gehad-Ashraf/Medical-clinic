package com.beetlware.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.beetlware.dto.AppointmentModel;
import com.beetlware.entity.Appointments;
import com.beetlware.enums.AppointmentStatus;
import com.beetlware.exceptions.AppointmentNotFoundException;
import com.beetlware.exceptions.AppointmentServiceException;
import com.beetlware.repository.AppointmentsRepository;
import com.beetlware.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppointmentsRepository appointmentRepository;

	@Override
	public void addAppointment(Appointments appointment) {
		try {
			appointmentRepository.save(appointment);
		} catch (DataAccessException e) {
			throw new AppointmentServiceException("Error occurred while adding appointment", e);
		}
	}

	@Override
	public void cancelAppointment(Long appointmentId, String cancellationReason) {
		try {
			Optional<Appointments> optionalAppointment = appointmentRepository.findById(appointmentId);
			optionalAppointment.ifPresent(appointment -> {
				appointment.setStatus(AppointmentStatus.CANCELED);
				appointment.setCancellationReason(cancellationReason);
				appointmentRepository.save(appointment);
			});
		} catch (EntityNotFoundException e) {
			throw new AppointmentNotFoundException("Appointment not found", e);
		} catch (DataAccessException e) {
			throw new AppointmentServiceException("Error occurred while canceling appointment", e);
		}
	}

	@Override
	public List<AppointmentModel> getAppointmentsByDate(Date date) {
		try {
			return appointmentRepository.findByAppointmentDate(date);
		} catch (Exception e) {
			throw new AppointmentServiceException(
					"Error occurred while fetching appointments by date: " + e.getMessage());
		}
	}

	@Override
	public List<AppointmentModel> getAppointmentsByPatient(String patientName) {
		try {
			return appointmentRepository.findByPatientName(patientName);
		} catch (Exception e) {
			throw new AppointmentServiceException(
					"Error occurred while fetching appointments by patient name: " + e.getMessage());
		}
	}

	@Override
	public List<Appointments> getPatientAppointmentHistory(Long patientId) {
		try {
			return appointmentRepository.findByPatientId(patientId);
		} catch (Exception e) {
			throw new AppointmentServiceException(
					"Error occurred while fetching appointments by history: " + e.getMessage());
		}
	}

}
