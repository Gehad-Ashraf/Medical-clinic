package com.beetlware.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.beetlware.dto.AppointmentModel;
import com.beetlware.entity.Appointments;
import com.beetlware.service.AppointmentService;

@RestController
@RequestMapping("/appointments")
public class AppointmentsController {

	@Autowired
	AppointmentService appointmentService;

	@PostMapping("/add")
	public ResponseEntity<String> addAppointment(@RequestBody Appointments appointment) {
		appointmentService.addAppointment(appointment);
		return ResponseEntity.ok("Appointment added successfully");
	}

	@DeleteMapping("/cancel/{appointmentId}")
	public ResponseEntity<String> cancelAppointment(@PathVariable Long appointmentId,
			@RequestBody String cancellationReason) {
		appointmentService.cancelAppointment(appointmentId, cancellationReason);
		return ResponseEntity.ok("Appointment canceled successfully");
	}

	@GetMapping("/by-date/{date}")
	public ResponseEntity<List<AppointmentModel>> getAppointmentsByDate(@PathVariable Date date) {
		List<AppointmentModel> appointments = appointmentService.getAppointmentsByDate(date);
		return ResponseEntity.ok(appointments);
	}

	@GetMapping("/by-patient/{name}")
	public ResponseEntity<List<AppointmentModel>> getAppointmentsByPatient(@PathVariable String name) {
		List<AppointmentModel> appointments = appointmentService.getAppointmentsByPatient(name);
		return ResponseEntity.ok(appointments);
	}

	@GetMapping("/patient-history/{patientId}")
	public ResponseEntity<List<Appointments>> getPatientAppointmentHistory(@PathVariable Long patientId) {
		List<Appointments> history = appointmentService.getPatientAppointmentHistory(patientId);
		return ResponseEntity.ok(history);
	}
}
