package com.beetlware.exceptions;

public class AppointmentServiceException extends RuntimeException {

	private static final long serialVersionUID = 5259513052884718388L;

	public AppointmentServiceException(String message) {
		super(message);
	}

	public AppointmentServiceException(String message, Throwable cause) {
		super(message, cause);
	}
}
