package com.beetlware.exceptions;

public class AppointmentNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -8710219971389397257L;

	public AppointmentNotFoundException(String message) {
		super(message);
	}

	public AppointmentNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}