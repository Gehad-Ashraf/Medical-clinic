package com.beetlware.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.beetlware.enums.AppointmentStatus;

import lombok.Data;

import java.util.Date;

@Entity
@Table(name = "appointments")
@Data
public class Appointments {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "appointment_date")
	private Date appointmentDate;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private AppointmentStatus status;

	@Column(name = "cancellation_reason")
	private String cancellationReason;

	@Column(name = "patient_id")
	private Long patientId;

}
