package com.beetlware.enums;

public enum AppointmentStatus {
//	SCHEDULED("scheduled"), CANCELED("canceled"), COMPLETED("completed");
	SCHEDULED, CANCELED, COMPLETED;
//	
//	private final String status;
//
//	AppointmentStatus( String status) {
//        this.status = status;
//    }
//	
//	public String getStatus() {
//		return status;
//	}
}