package com.beetlware.dto;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.beetlware.enums.AppointmentStatus;

import lombok.Data;

@Data
public class AppointmentModel {

	private Long id;

	private LocalDate appointmentDate;
	private Long patientId;
	private String patientName;

	private AppointmentStatus status;

	private String cancellationReason;

}
